@echo off
if not exist bin mkdir bin
javac -d bin src\chatbot\model\*.java src\chatbot\nlp\*.java src\chatbot\service\*.java src\chatbot\gui\*.java src\chatbot\Main.java
if errorlevel 1 pause & exit /b 1
java -cp bin chatbot.gui.ChatbotGUI
pause
