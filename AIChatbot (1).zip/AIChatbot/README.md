# Nova - Java AI Chatbot

A completed console + Swing GUI Java chatbot for an academic AI Chatbot task.

## Features
- Java-based interactive chatbot
- NLP-style tokenization and stop-word filtering
- Rule-based intent classification with keyword overlap and phrase matching
- FAQ/training examples for common questions
- Intents: greeting, farewell, thanks, name, help, time, date, Java, college, study, project, contact, weather
- Real-time Swing GUI
- Console interface
- Input validation / unknown-intent fallback
- Clean package structure and reusable chatbot engine

## Requirements
- JDK 17+ recommended (JDK 14+ also works because the project uses records)
- No external libraries required

## Run on Windows
Double-click `run.bat`.

## Run manually
```text
javac -d bin src/chatbot/model/*.java src/chatbot/nlp/*.java src/chatbot/service/*.java src/chatbot/gui/*.java src/chatbot/Main.java
java -cp bin chatbot.gui.ChatbotGUI
```

For console mode:
```text
java -cp bin chatbot.Main
```

## How the NLP works
1. Input is normalized and tokenized.
2. Common stop words are removed.
3. The input is compared with trained FAQ phrases.
4. A combined coverage/Jaccard score selects the best intent.
5. If confidence is below the threshold, the bot uses an unknown-intent response.

This is intentionally an offline rule-based NLP chatbot, satisfying the assignment requirement without requiring paid APIs or internet access.
