package chatbot.nlp;

import chatbot.model.*;
import java.util.*;

public class IntentClassifier {
    private final List<TrainingExample> training = List.of(
        new TrainingExample(Intent.GREETING, new String[]{"hello","hi","hey","good morning","good evening","namaste"}),
        new TrainingExample(Intent.FAREWELL, new String[]{"bye","goodbye","see you","exit","quit"}),
        new TrainingExample(Intent.THANKS, new String[]{"thanks","thank you","thx","appreciate it"}),
        new TrainingExample(Intent.NAME, new String[]{"what is your name","who are you","your name"}),
        new TrainingExample(Intent.HELP, new String[]{"help","what can you do","commands","options"}),
        new TrainingExample(Intent.TIME, new String[]{"what time is it","current time","time now"}),
        new TrainingExample(Intent.DATE, new String[]{"what is today's date","today's date","current date","date today"}),
        new TrainingExample(Intent.JAVA, new String[]{"java","java programming","oops in java","java language","inheritance","interface"}),
        new TrainingExample(Intent.COLLEGE, new String[]{"college","university","campus","gehu","graphic era"}),
        new TrainingExample(Intent.STUDY, new String[]{"study","exam","revision","how to prepare","learning tips"}),
        new TrainingExample(Intent.PROJECT, new String[]{"project","final year project","build an app","software project"}),
        new TrainingExample(Intent.CONTACT, new String[]{"contact","email","phone","reach you"}),
        new TrainingExample(Intent.WEATHER, new String[]{"weather","temperature","rain","forecast"})
    );

    public Intent classify(String input) {
        Set<String> inputWords = Tokenizer.keywords(input);
        Intent best = Intent.UNKNOWN;
        double bestScore = 0;
        for (TrainingExample ex : training) {
            double localBest = 0;
            for (String phrase : ex.phrases()) localBest = Math.max(localBest, score(inputWords, Tokenizer.keywords(phrase), input, phrase));
            if (localBest > bestScore) { bestScore = localBest; best = ex.intent(); }
        }
        return bestScore >= 0.28 ? best : Intent.UNKNOWN;
    }

    private double score(Set<String> input, Set<String> phrase, String raw, String p) {
        if (raw.toLowerCase(Locale.ROOT).contains(p.toLowerCase(Locale.ROOT))) return 1.0;
        if (phrase.isEmpty()) return 0;
        long common = phrase.stream().filter(input::contains).count();
        double jaccard = common / (double)(input.size() + phrase.size() - common);
        double coverage = common / (double)phrase.size();
        return 0.65 * coverage + 0.35 * jaccard;
    }
}
