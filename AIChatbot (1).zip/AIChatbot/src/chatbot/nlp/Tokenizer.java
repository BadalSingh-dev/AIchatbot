package chatbot.nlp;

import java.util.*;

public final class Tokenizer {
    private Tokenizer() {}

    public static List<String> tokenize(String text) {
        if (text == null) return List.of();
        String cleaned = text.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9\\s]", " ");
        return Arrays.stream(cleaned.trim().split("\\s+"))
                .filter(s -> !s.isBlank())
                .toList();
    }

    public static Set<String> keywords(String text) {
        Set<String> stop = Set.of("a","an","the","is","are","am","i","you","me","my","to","of","for","in","on","and","or","please","can","could","would","do","does","what","how","where","when","tell","about");
        Set<String> result = new HashSet<>();
        for (String token : tokenize(text)) if (!stop.contains(token)) result.add(token);
        return result;
    }
}
