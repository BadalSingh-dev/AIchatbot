package chatbot.model;

public record TrainingExample(Intent intent, String[] phrases) {}
