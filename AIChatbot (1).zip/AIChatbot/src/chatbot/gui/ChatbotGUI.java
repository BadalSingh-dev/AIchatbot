package chatbot.gui;

import chatbot.service.ChatbotEngine;
import javax.swing.*;
import java.awt.*;

public class ChatbotGUI extends JFrame {
    private final JTextArea chatArea = new JTextArea();
    private final JTextField input = new JTextField();
    private final ChatbotEngine engine = new ChatbotEngine();

    public ChatbotGUI() {
        setTitle("Nova - Java AI Chatbot");
        setSize(720, 520);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10,10));

        JLabel title = new JLabel("  🤖 Nova AI Chatbot", SwingConstants.LEFT);
        title.setFont(new Font("SansSerif", Font.BOLD, 22));
        add(title, BorderLayout.NORTH);

        chatArea.setEditable(false);
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);
        chatArea.setFont(new Font("SansSerif", Font.PLAIN, 15));
        chatArea.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        chatArea.append("Nova: Hello! I'm a Java NLP chatbot. Type 'help' to see what I can do.\n\n");
        add(new JScrollPane(chatArea), BorderLayout.CENTER);

        JPanel bottom = new JPanel(new BorderLayout(8,8));
        bottom.setBorder(BorderFactory.createEmptyBorder(0,10,10,10));
        JButton send = new JButton("Send");
        bottom.add(input, BorderLayout.CENTER);
        bottom.add(send, BorderLayout.EAST);
        add(bottom, BorderLayout.SOUTH);

        send.addActionListener(e -> sendMessage());
        input.addActionListener(e -> sendMessage());
    }

    private void sendMessage() {
        String msg = input.getText().trim();
        if (msg.isEmpty()) return;
        chatArea.append("You: " + msg + "\n");
        String reply = engine.reply(msg);
        chatArea.append("Nova: " + reply + "\n\n");
        input.setText("");
        if (msg.equalsIgnoreCase("exit") || msg.equalsIgnoreCase("quit") || msg.equalsIgnoreCase("bye")) {
            Timer timer = new Timer(700, e -> System.exit(0)); timer.setRepeats(false); timer.start();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ChatbotGUI().setVisible(true));
    }
}
