package chatbot;

import chatbot.service.ChatbotEngine;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ChatbotEngine bot = new ChatbotEngine();
        Scanner sc = new Scanner(System.in);
        System.out.println("=== Nova Java AI Chatbot ===");
        System.out.println("Type 'help' for options, 'exit' to quit.\n");
        while (true) {
            System.out.print("You: ");
            String input = sc.nextLine();
            System.out.println("Nova: " + bot.reply(input));
            if (input.equalsIgnoreCase("exit") || input.equalsIgnoreCase("quit") || input.equalsIgnoreCase("bye")) break;
        }
    }
}
