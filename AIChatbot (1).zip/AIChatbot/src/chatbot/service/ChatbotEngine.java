package chatbot.service;

import chatbot.model.Intent;
import chatbot.nlp.IntentClassifier;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class ChatbotEngine {
    private final IntentClassifier classifier = new IntentClassifier();
    private final Map<Intent, List<String>> responses = new EnumMap<>(Intent.class);

    public ChatbotEngine() {
        responses.put(Intent.GREETING, List.of("Hello! 👋 How can I help you today?", "Hi! Ask me about Java, projects, studying, or my commands."));
        responses.put(Intent.FAREWELL, List.of("Goodbye! Have a great day.", "See you later! 👋"));
        responses.put(Intent.THANKS, List.of("You're welcome!", "Happy to help!"));
        responses.put(Intent.NAME, List.of("I'm Nova, a Java-based AI chatbot demo.", "You can call me Nova."));
        responses.put(Intent.HELP, List.of("I can answer FAQs about Java, projects, study tips, college, time/date, and basic chatbot commands. Try: 'Explain inheritance in Java'."));
        responses.put(Intent.JAVA, List.of("Java is an object-oriented language. Core OOP concepts include encapsulation, inheritance, polymorphism, and abstraction."));
        responses.put(Intent.COLLEGE, List.of("I can answer general college-related questions, but I don't have live access to university notices or schedules."));
        responses.put(Intent.STUDY, List.of("For exams: break the syllabus into units, learn concepts first, practice previous-year questions, and reserve the last day for active recall."));
        responses.put(Intent.PROJECT, List.of("A good Java project should have clear requirements, modular classes, validation, persistence or APIs where useful, and a README with setup steps."));
        responses.put(Intent.CONTACT, List.of("This demo chatbot runs locally, so it does not have a real contact number or email."));
        responses.put(Intent.WEATHER, List.of("I don't have live weather access in this offline Java demo. You can connect a weather API to add real-time forecasts."));
    }

    public String reply(String message) {
        Intent intent = classifier.classify(message);
        if (intent == Intent.TIME) return "Current local time: " + LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm:ss a"));
        if (intent == Intent.DATE) return "Today's date: " + LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMMM yyyy"));
        if (intent == Intent.UNKNOWN) return "I didn't quite understand that. Try asking about Java, projects, study tips, college, time/date, or type 'help'.";
        List<String> choices = responses.getOrDefault(intent, List.of("I can help with that."));
        return choices.get(Math.floorMod(message.hashCode(), choices.size()));
    }
}
